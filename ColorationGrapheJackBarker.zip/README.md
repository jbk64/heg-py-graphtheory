# heg-py-graphtheory

A naive graph coloring algorithm written in Python.